
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point p0 = new Point();
		Point p1 = new Point(5,10);
		System.out.println(p0.distance(p1));
		System.out.println(p1.distance());		
		System.out.println(p1.distance(10, 15));
	}

}
