/**
 * Created by Agreen on 11/11/2015.
 */
public interface Moveable {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}
