/**
 * Created by Agreen on 11/11/2015.
 */
public interface GeometricableObject {
    double perimeter();
    double area();
}
