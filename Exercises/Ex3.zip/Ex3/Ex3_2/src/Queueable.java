/**
 * Created by alongreen on 12/11/2015.
 */
public interface Queueable {

    void add(int value);
    int remove();
    boolean isEmpty();


}
