/**
 * Created by alongreen on 14/11/2015.
 */
public interface Strategy {
    boolean checkTemperature(int temperature);

}
